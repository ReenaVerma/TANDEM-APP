// prefer default export if available
const preferDefault = m => m && m.default || m


exports.layouts = {
  "layout---index": preferDefault(require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/layouts/index.js"))
}

exports.components = {
  "component---cache-dev-404-page-js": preferDefault(require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/dev-404-page.js")),
  "component---src-pages-404-js": preferDefault(require("/Users/reenaverma/TESTS/gatsby-example-site/src/pages/404.js")),
  "component---src-pages-index-js": preferDefault(require("/Users/reenaverma/TESTS/gatsby-example-site/src/pages/index.js")),
  "component---src-pages-test-js": preferDefault(require("/Users/reenaverma/TESTS/gatsby-example-site/src/pages/Test.js"))
}

exports.json = {
  "layout-index.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/layout-index.json"),
  "dev-404-page.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/dev-404-page.json"),
  "404.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/404.json"),
  "index.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/index.json"),
  "test.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/test.json"),
  "404-html.json": require("/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/404-html.json")
}