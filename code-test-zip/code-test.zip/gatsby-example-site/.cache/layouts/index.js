
  import React from "react"
  import Component from "/Users/reenaverma/TESTS/gatsby-example-site/src/layouts/index.js"
  import data from "/Users/reenaverma/TESTS/gatsby-example-site/.cache/json/layout-index.json"

  export default (props) => <Component {...props} {...data} />
  