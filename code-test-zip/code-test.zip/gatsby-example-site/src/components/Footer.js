import React from 'react';
// import Link from 'gatsby-link';

const Footer = () => (
  <section>
    <footer>Reena Verma</footer>
  </section>
);

export default Footer;
